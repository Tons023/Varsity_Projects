
/**
 * Write a description of class Printing here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */

import java.io.*;

public class Printing
{
    public static void main()
    {
        int num = 10;
        char ch = 'F';
        String str = "Spaan";
        double d = 13.5;
        float f = 10.2f;
        boolean bool = false;
        
        System.out.println();
        System.out.println(num);
        System.out.println(ch);
        System.out.println(str);
        System.out.println(d);
        System.out.println(f);
        System.out.println(bool);
        System.out.println("Hello");
    }
}

#include <iostream>
#include <math.h>
#include <cctype>
#include <cstring>

using namespace std;

int main()
{
    double hours;
    int count = 0;
    string answer;
    int amount;


    do
    {
        cout << "Enter number of hours parked: ";
        cin >> hours;

        if(hours <= 3)
        {
            amount = round(hours) * 5;
        }
        else if(hours > 3 && hours <=6)
        {
            amount = round(hours) * 10;
        }
        else
            amount = round(hours) * 15;

        cout << "Hours parked: " << round(hours) << endl;
        cout << "Amount to pay: R" << amount << endl;

        cout << "Another fee to calculate (Y or N): ";
        cin >> toupper(answer);
    }

    while(answer == 'Y');




    return 0;
}

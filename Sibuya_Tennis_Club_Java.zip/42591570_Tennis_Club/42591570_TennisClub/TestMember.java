import java.util.Scanner;
public class TestMember
{
    public static void main(String[] args)
     {        
                 
         Scanner input=new Scanner(System.in);
         
         System.out.print("Enter name: ");        
         String name=input.nextLine();
         
         System.out.print("Enter age: ");        
         int age=input.nextInt();    
         
         System.out.print("Enter number of matches won: ");        
         int matchesWon=input.nextInt();
         
         Member m = new Member(name, age);        
         m.setMatchesWon(matchesWon);    
         
         System.out.println(m.toString());        
         String category=m.determineCategory();
         
         char rating=m.determineRating();        
         System.out.println("Category: " + category);        
         System.out.println("Rating: " + rating);        
         input.close();    
    } 
}

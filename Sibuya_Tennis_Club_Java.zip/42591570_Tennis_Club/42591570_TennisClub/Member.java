
/**
 * Write a description of class Member here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Member
{
    private String name;    
    private int age;    
    private int matchesWon;          
   
    public Member()
    {              
   
    }    
   
       
   
    public Member(String name, int age)
    {        
        super();        
        this.name = name;        
        this.age = age;    
    }    
   
       
    public String getName()
    {        
        return name;    
   
    }    
   
       
    public int getAge()
    {        
        return age;    
    }    
   
       
    public int getMatchesWon()
    {        
        return matchesWon;    
    }    
   
         
    public void setMatchesWon(int matchesWon)
    {        
        this.matchesWon = matchesWon;    
    }          
   
    public String determineCategory()
    {        
        if(age<16)    
        {
            return "Junior";
        }
        else if(age>45)            
        {
            return "Retired";    
        }
        else    
        {
            return "Senior";
        }
    }      
   
    public char determineRating()
    {        
        char rating='\0';
       
        switch(matchesWon)        
        {            
            case 0:
            case 1:
            case 2:
            case 3:
            case 4:
            case 5:
            case 6:
            case 7:
            case 8:
            case 9:                
                rating='E';                
                break;            
            case 10:
            case 11:
            case 12:
            case 13:
            case 14:                  
                rating='D';                
                break;            
            case 15:
            case 16:
            case 17:
            case 18:
            case 19:                
                rating='C';                
                break;            
            case 20:
            case 21:
            case 22:
            case 23:
            case 24:
            case 25:                
                rating='B';                
                break;            
            default:                
                rating='A';                      
        }        
        return rating;    
    }    
   
    @Override    
   
    public String toString()
    {        
        StringBuilder str=new StringBuilder();        
        str.append("Name:").append(name).append("\nAge:").append(age).append("\nNumber of matches won:").append(matchesWon);        
        return str.toString();    
    } 
}

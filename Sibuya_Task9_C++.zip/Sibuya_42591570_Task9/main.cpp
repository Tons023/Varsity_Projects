#include <iostream>

using namespace std;

int main()
{
    int num1, num2, num3, largest;

    cout << "Enter value 1: ";
    cin >> num1;

    cout << "Enter value 2: ";
    cin >> num2;

    cout << "Enter value 3: ";
    cin >> num3;

    if((num1 >= num2) && (num1 >= num3))
    {
        largest = num1;
    }
    else if((num2 >= num1) && (num2 >= num3))
        largest = num2;

    else
        largest = num3;

    cout << "The largest number between "
         << num1 << ", " << num2 << " and "
         << num3 << " is " << largest << endl;

    return 0;
}

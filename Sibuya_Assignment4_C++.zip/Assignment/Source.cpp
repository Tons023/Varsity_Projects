#include<iostream>

using namespace std;

int main()
{
	int empNum, hours, minutes;
	int hoursIn, minutesIn;
	double wage;
	double hrs, min = 0.0;
	double clocked;
	

	cout << "Please enter the employee number: ";
	cin >> empNum;

	cout << "Please enter the clocked in time (hours): ";
	cin >> hoursIn;
	cout << "Please enter the clocked in time (minutes): ";
	cin >> minutesIn;

	cout << "Please enter the clocked out time (hours): ";
	cin >> hours;
	cout << "Please enter the clocked out time (minutes): ";
	cin >> minutes;

	cout << "Please enter the hourly wage rate: ";
	cin >> wage;

	hrs = hoursIn / 1;
	min = minutesIn / 60;

	clocked = hrs + min;
	
	cout << clocked << endl;

	

	system("pause");
	return 0;
}
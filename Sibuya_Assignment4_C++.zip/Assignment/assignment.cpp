#include<iostream>

using namespace std;

void getCorrectAnswer(char login, int number, int digit)
{
	do
{

	switch (login)
	{
	case 'Y':
	case 'y':
		for (int a = 0; a < 5; a++)
		{
			cout << "Enter the " << a + 1 << " digit number: ";
			cin >> digit;
		}

		for (int a = 0; a < 1; a++)
		{
			if (digit > 5)
			{

			}
			else
			{
				cout << "The digit is incorrect" << endl;
			}
		}
		for (int a = 4; a < 5; a++)
		{
			if (digit % 2 == 0)
			{
				
			}
			else
			{
				cout << "The digit is incorrect" << endl;
			}
		}
		break;
	default:
		cout << "The code you have entered is wrong" << endl;

		break;
	}

} while (login == 'Y' || login == 'N');
}

int createNewLogin(char login)
{
	int number = 0;
	switch (login)
	{
	case 'N':
	case 'n':

		for (int a = 0; a < 4; a++)
		{
			number = 6 + rand() % 4;
			cout << number << " " << endl;
		}
		for (int b = 4; b < 5; b++)
		{
			number = 6 + (2 * rand()) % 4;
			cout << number << " " << endl;
		}
		break;

	}
	return number;
}

int testLoginForCorrectness(char login)
{
	int digit;
	int answer;
	switch (login)
	{
	case 'Y':
	case 'y':
		for (int a = 0; a < 5; a++)
		{
			cout << "Enter the " << a + 1 << " digit number: ";
			cin >> digit;
		}

		for (int a = 0; a < 1; a++)
		{
			if (digit > 5)
			{
				cout << "The " << a + 1 << " Digit is correct" << endl;
				answer = 0;
				cout << answer << endl;
			}
			else
			{
				cout << "The " << a + 1 << " Digit is incorrect" << endl;
				answer = 1;
				cout << answer << endl;
			}

			for (int a = 4; a < 5; a++)
			{

				if (digit % 2 == 0)
				{
					cout << "The " << a + 1 << " Digit is correct" << endl;
					answer = 0;
					cout << answer << endl;
				}
				else
				{
					cout << "The " << a + 1 << " Digit is incorrect" << endl;
					answer = 1;
					cout << answer << endl;
				}
				break;
			}
		}
	}
	return answer;
}

int main()
{
	char login;
	int number = 0, digit = 0;

	cout << "Do you've the login number? (PRESS 'Y' for YES OR 'N' for NO) ";
	cin >> login;
	
	
	number = createNewLogin(login);
	digit = testLoginForCorrectness(login);

	system("pause");
	return 0;
}

int convertToProperFraction(int hours, int minutes)
{
	int fraction;

	cout << "Please enter the time (hours): ";
	cin >> hours;
	cout << "Please enter the time (minutes): ";
	cin >> minutes;
	
	fraction = 

	return fraction;
}
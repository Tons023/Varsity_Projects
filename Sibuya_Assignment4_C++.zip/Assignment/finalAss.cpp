#include<iostream>

using namespace std;

void getCorrectAnswer(char login, int digit)
{
	do
{

	switch (login)
	{
	case 'Y':
	case 'y':
		for (int a = 0; a < 5; a++)
		{
			cout << "Enter the " << a + 1 << " digit number: ";
			cin >> digit;
		}

		for (int a = 0; a < 1; a++)
		{
			if (digit > 5)
			{

			}
			else
			{
				cout << "The digit is incorrect" << endl;
			}
		}
		for (int a = 4; a < 5; a++)
		{
			if (digit % 2 == 0)
			{
				
			}
			else
			{
				cout << "The digit is incorrect" << endl;
			}
		}
		break;
	default:
		cout << "The code you have entered is wrong" << endl;

		break;
	}

} while (login == 'Y' || login == 'N');
}

int createNewLogin(char login)
{
	int number = 0;
	switch (login)
	{
	case 'N':
	case 'n':

		for (int a = 0; a < 4; a++)
		{
			number = 6 + rand() % 4;
			cout << number << " " << endl;
		}
		for (int b = 4; b < 5; b++)
		{
			number = 6 + (2 * rand()) % 4;
			cout << number << " " << endl;
		}
		break;

	}
	return number;
}

int testLoginForCorrectness(char login)
{
	int digit;
	int answer;
	switch (login)
	{
	case 'Y':
	case 'y':
		for (int a = 0; a < 5; a++)
		{
			cout << "Enter the " << a + 1 << " digit number: ";
			cin >> digit;
		}

		for (int a = 0; a < 1; a++)
		{
			if (digit > 5)
			{
				cout << "The " << a + 1 << " Digit is correct" << endl;
				answer = 0;
				cout << answer << endl;
			}
			else
			{
				cout << "The " << a + 1 << " Digit is incorrect" << endl;
				answer = 1;
				cout << answer << endl;
			}

			for (int a = 4; a < 5; a++)
			{

				if (digit % 2 == 0)
				{
					cout << "The " << a + 1 << " Digit is correct" << endl;
					answer = 0;
					cout << answer << endl;
				}
				else
				{
					cout << "The " << a + 1 << " Digit is incorrect" << endl;
					answer = 1;
					cout << answer << endl;
				}
				break;
			}
		}
	}
	return answer;
}

int promptAndEnterCategoryCode()
{
	char code;
	cout << "Enter the category code ('C' for Casual, 'T' for Temporary OR 'P' for Permanent): ";
	cin >> code;

	return code;
}

int calculateNettPay(float medical, float deductions, float grossPay, float pension, char code)
{
	float netPay;
	switch (code)
	{
	case 'C':
	case 'c':
		medical = grossPay * 0;
		pension = grossPay * 0;
		deductions = medical + pension;
		netPay = grossPay - deductions;
		break;
	case 'T':
	case 't':
		medical = grossPay * 0.015;
		pension = grossPay * 0.01;
		deductions = medical + pension;
		netPay = grossPay - deductions;
		break;
	case 'P':
	case 'p':
		medical = grossPay * 0.015;
		pension = grossPay * 0.027;
		deductions = medical + pension;
		netPay = grossPay - deductions;
		break;

	default:
		cout << "You have entered an invalid code" << endl;
		break;
	}

	return netPay;
}


int main()
{
	
	char login;
	int number, digit;
	int empNum;
	float minutesOut;
	float minutesIn;
	float wage;
	float hrs, min;
	float clockedIn, clockedOut;
	float hrsWorked = 0;
	float timeOut, timeIn;
	const int size = 5;
	
	float hoursOut = 0;
	float hoursIn = 0, hoursWorked;
	float averageIn, averageOut;
	char  code;
	float medical = 0, pension = 0, deductions = 0, grossPay = 0, netPay = 0;

	cout << "Do you've the login number? (PRESS 'Y' for YES OR 'N' for NO) ";
	cin >> login;
	
	do{
		
		getCorrectAnswer(login, digit);
		number = createNewLogin(login);
		answer = testLoginForCorrectness(login);
		
		
		
		cout << "Do you've the login number? (PRESS 'Y' for YES OR 'N' for NO) " << endl;
		cin >> login;


	} while (login != 'Y' || login != 'N');
	
	

	cout << "Please enter the employee number: ";
	cin >> empNum;
	//

	for (int i = 0; i < 2; i++)
	{
		cout << "Enter the clocked in and out time for day " << i + 1 << " " << endl;

		cout << "Please enter the clocked in time (hours): ";
		cin >> hoursIn;
		cout << "Please enter the clocked in time (minutes): ";
		cin >> minutesIn;
		//
		cout << "Please enter the clocked out time (hours): ";
		cin >> hoursOut;
		cout << "Please enter the clocked out time (minutes): ";
		cin >> minutesOut;
		//
		
		clockedOut = hoursOut + minutesOut;
		clockedIn = hoursIn + minutesIn;
		hrsWorked = clockedOut - clockedIn;
		hrsWorked++;
	}
	//
	

	cout << "Please enter the hourly wage rate: ";
	cin >> wage;
	//
	
	double weekSal = hrsWorked*wage;
	cout << weekSal << endl;

	hrs = hoursIn / 1;
	min = minutesIn / 60;
	clockedIn = hrs + min;
	//
	hrs = hoursOut / 1;
	min = minutesOut / 60;
	clockedOut = hrs + min;
	//
	cout << "The clocked time IN is " << setw(2) << fixed << setprecision(2) << clockedIn << " Hours" << endl;
	cout << "The clocked time OUT is " << setw(2) << fixed << setprecision(2) << clockedOut << " Hours" << endl;
	//
	
	grossPay = wage * hrsWorked;
	//
	deductions = (grossPay * 0.01) + (grossPay * 0.015);
	netPay = grossPay - deductions;
	//
	cout << "====================================================================================" << endl;
	cout << "The Employee number " << empNum << " is earning the Gross pay of R" << grossPay << " and the Net pay of R" << netPay << endl;
	cout << "====================================================================================" << endl;
	//

	//
	cout << "Enter the category code ('C' for Casual, 'T' for Temporary OR 'P' for Permanent): ";
	cin >> code;
	do
	{
		code = promptAndEnterCategoryCode();
		netPay = calculateNettPay(medical, deductions, grossPay, pension, code);
	
		cout << "Enter the category code ('C' for Casual, 'T' for Temporary OR 'P' for Permanent): ";
		cin >> code;

	} while (code != 'C' || code != 'T' || code != 'P');


	cout << "The Employee number " << empNum << " of category " << code << " and the gross pay is R" <<
		grossPay << " The Medical Aid contribution is R" << medical << " The pension contribution is R" <<
		pension << " And the net pay is R" << netPay << end;

	digit = testLoginForCorrectness(login
	
	
	float timeInWeek[size];
	float timeOutWeek[size];
	int hoursWorkedWeek[size];
	
	for (int i = 0; i < 5; i++)
	{
		
		cout << "The time in for day " << timeInWeek[i + 1] << timeIn << endl;
		cout << "The time out for day " << timeInWeek[i + 1] << timeOut << endl;

		hoursIn = hoursIn + timeIn;
		
	}

	for (int c = 0; c < 5; c++)
	{
		
		cout << "The time in for day " <<timeOutWeek[c + 1]<< timeIn << endl;
		cout << "The time out for day " <<timeOutWeek[c + 1]<< timeOut << endl;
		hoursOut = hoursOut + timeOut;
	}

	for (int j = 0; j < 5; j++)
	{

		hoursWorkedWeek[j] = hoursOut - hoursIn;
	}

	timeInOutCalculations(hoursOut, hoursIn, averageOut, averageIn);
	hoursWorked = determineAveHoursWorked();
	
	cout << "Please enter the employee number: ";
	cin >> empNum;


	}while(empNum != -1);
	
	system("pause");
	return 0;
}
#include<iostream>
#include<iomanip>
using namespace std;

int main()
{
	int empNum;
	float hoursOut, minutesOut;
	float hoursIn, minutesIn;
	float wage;
	float hrs, min;
	float clockedIn, clockedOut, hrsWorked;
	float grossPay, netPay, deductions;

	cout << "Please enter the employee number: ";
	cin >> empNum;
	//
	cout << "Please enter the clocked in time (hours): ";
	cin >> hoursIn;
	cout << "Please enter the clocked in time (minutes): ";
	cin >> minutesIn;
	//
	cout << "Please enter the clocked out time (hours): ";
	cin >> hoursOut;
	cout << "Please enter the clocked out time (minutes): ";
	cin >> minutesOut;
	//
	cout << "Please enter the hourly wage rate: ";
	cin >> wage;
	//
	hrs = hoursIn ;
	min = minutesIn / 100;
	timeIn = hrs + min;
	//
	hrs = hoursOut;
	min = minutesOut / 100;
	timeOut = hrs + min;
	//
	cout <<"The clocked time IN is "<< setw(2) << fixed << setprecision(2) << timeIn <<" Hours"<<endl;
	cout << "The clocked time OUT is " << setw(2) << fixed << setprecision(2) << timeOut << " Hours" << endl;
	//
	hrsWorked = timeOut - timeIn;
	grossPay = wage * hrsWorked;
	//
	deductions = (grossPay * 0.01) + (grossPay * 0.015);
	netPay = grossPay - deductions;
	//
	cout << "====================================================================================" << endl;
	cout << "The Employee number " << empNum << " is earning the Gross pay of R" << grossPay << " and the Net pay of R" << netPay << endl;
	cout << "====================================================================================" << endl;
	//
	system("pause");
	return 0;
}
//
#include<iostream>
#include<iomanip>
using namespace std;

int main()
{
	int number;
	
		for (int i = 0; i < 4; i++)
		{
			number = 6 + rand() % 4;
			cout << number << endl;
		}
		for (int i = 4; i < 5; i++)
		{
			number = 6 + (2 * rand()) % 4;
			cout << number << endl;
		}
	
	
	system("pause");
	return 0;
}
//

#include<iostream>
#include<iomanip>

using namespace std;

int main()
{
	char login;
	int number, digit;

	cout << "Do you've the login number? (PRESS 'Y' for YES OR 'N' for NO) ";
	cin >> login;

	switch (login)
	{
	case 'Y':
	case 'y':
		for (int a = 0; a < 5; a++)
		{
			cout << "Enter the " << a + 1 << " digit number: ";
			cin >> digit;
			//
			for (int a = 0; a < 1; a++)
			{
				if (digit > 5)
				{
					cout << "*";
				}
			}
			for (int a = 4; a < 5; a++)
			{
				if (digit % 2 == 0)
				{
					cout << "#";
				}
			}
		}

		break;
	case 'N':
		case 'n':

		for (int a = 0; a < 4; a++)
		{
			number = 6 + rand() % 4;
			cout << number << " ";
		}
		for (int b = 4; b < 5; b++)
		{
			number = 6 + (2 * rand()) % 4;
			cout << number << " ";
		}
		break;
	default:
		cout << "The code you have entered is wrong" << endl;
		break;

	}
	
		system("pause");
		return 0;
}

#include<iostream>

using namespace std;

int main()
{
	char code;
	float medical, pension, deductions, grossPay, netPay;
	//
	cout << "Enter the category code ('C' for Casual, 'T' for Temporary OR 'P' for Permanent): ";
	cin >> code;

	switch (code)
	{
	case 'C':
	case 'c':
		medical = grossPay * 0;
		pension = grossPay * 0;
		deductions = medical + pension;
		netPay = grossPay - deductions;
		break;
	case 'T':
	case 't':
		medical = grossPay * 0.015;
		pension = grossPay * 0.01;
		deductions = medical + pension;
		netPay = grossPay - deductions;
		break;
	case 'P':
	case 'p':
		medical = grossPay * 0.015;
		pension = grossPay * 0.027;
		deductions = medical + pension;
		netPay = grossPay - deductions;
		break;

	default:
		cout << "You have entered an invalid code" << endl;
		break;
	}

	cout << "The Employee number " << empNum << " of category " << code << " and the gross pay is R" <<
		grossPay << " The Medical Aid contribution is R" << medical << " The pension contribution is R" << 
		pension << " And the net pay is R" << netPay << end;

	system("pause");
	return 0;
}

//

#include<iostream>

using namespace std;

int main()
{
	char login;
	int number, digit;

	cout << "Do you've the login number? (PRESS 'Y' for YES OR 'N' for NO) ";
	cin >> login;
	do{

		switch (login)
		{
		case 'Y':
		case 'y':
			for (int a = 0; a < 5; a++)
			{
				cout << "Enter the " << a + 1 << " digit number: ";
				cin >> digit;
			}

			for (int a = 0; a < 1; a++)
			{
				if (digit > 5)
				{
					cout << "*";
				}
			}
			for (int a = 4; a < 5; a++)
			{
				if (digit % 2 == 0)
				{
					cout << "#";
				}
			}
			break;
		case 'N':
		case 'n':

			for (int a = 0; a < 4; a++)
			{
				number = 6 + rand() % 4;
				cout << number << " ";
			}
			for (int b = 4; b < 5; b++)
			{
				number = 6 + (2 * rand()) % 4;
				cout << number << " ";
			}
			break;
		default:
			cout << "The code you have entered is wrong" << endl;
			
			break;
		}

		cout << "Do you've the login number? (PRESS 'Y' for YES OR 'N' for NO) " << endl;
		cin >> login;


	} while (login != 'Y' || login != 'N');

	system("pause");
	return 0;
}
//
#include<iostream>

using namespace std;

int main()
{
	char code;
	float medical, pension, deductions, grossPay, netPay;
	//
	cout << "Enter the category code ('C' for Casual, 'T' for Temporary OR 'P' for Permanent): ";
	cin >> code;
	do
	{
		switch (code)
		{
		case 'C':
		case 'c':
			medical = grossPay * 0;
			pension = grossPay * 0;
			deductions = medical + pension;
			netPay = grossPay - deductions;
			break;
		case 'T':
		case 't':
			medical = grossPay * 0.015;
			pension = grossPay * 0.01;
			deductions = medical + pension;
			netPay = grossPay - deductions;
			break;
		case 'P':
		case 'p':
			medical = grossPay * 0.015;
			pension = grossPay * 0.027;
			deductions = medical + pension;
			netPay = grossPay - deductions;
			break;

		default:
			cout << "You have entered an invalid code" << endl;
			break;
		}

		cout << "Enter the category code ('C' for Casual, 'T' for Temporary OR 'P' for Permanent): ";
		cin >> code;

	} while (code != 'C' || code != 'T' || code != 'P');


	cout << "The Employee number " << empNum << " of category " << code << " and the gross pay is R" <<
		grossPay << " The Medical Aid contribution is R" << medical << " The pension contribution is R" <<
		pension << " And the net pay is R" << netPay << end;

	system("pause");
	return 0
}
//
#include<iostream>
#include<iomanip>
using namespace std;

int main()
{
	int empNum;
	float hoursOut, minutesOut;
	float hoursIn, minutesIn;
	float wage;
	float hrs, min;
	float clockedIn, clockedOut;
	float grossPay, netPay, deductions;
	float hrsWorked = 0;

	cout << "Please enter the employee number: ";
	cin >> empNum;
	//

	for (int i = 0; i < 2; i++)
	{
		cout << "Enter the clocked in and out time for day " << i + 1 << " " << endl;

		cout << "Please enter the clocked in time (hours): ";
		cin >> hoursIn;
		cout << "Please enter the clocked in time (minutes): ";
		cin >> minutesIn;
		//
		cout << "Please enter the clocked out time (hours): ";
		cin >> hoursOut;
		cout << "Please enter the clocked out time (minutes): ";
		cin >> minutesOut;
		//
		
		clockedOut = hoursOut + minutesOut;
		clockedIn = hoursIn + minutesIn;
		hrsWorked = clockedOut - clockedIn;
		hrsWorked++;
	}
	//
	

	cout << "Please enter the hourly wage rate: ";
	cin >> wage;
	//
	
	double weekSal = hrsWorked*wage;
	cout << weekSal << endl;

	hrs = hoursIn / 1;
	min = minutesIn / 60;
	clockedIn = hrs + min;
	//
	hrs = hoursOut / 1;
	min = minutesOut / 60;
	clockedOut = hrs + min;
	//
	cout << "The clocked time IN is " << setw(2) << fixed << setprecision(2) << clockedIn << " Hours" << endl;
	cout << "The clocked time OUT is " << setw(2) << fixed << setprecision(2) << clockedOut << " Hours" << endl;
	//
	
	grossPay = wage * hrsWorked;
	//
	deductions = (grossPay * 0.01) + (grossPay * 0.015);
	netPay = grossPay - deductions;
	//
	cout << "====================================================================================" << endl;
	cout << "The Employee number " << empNum << " is earning the Gross pay of R" << grossPay << " and the Net pay of R" << netPay << endl;
	cout << "====================================================================================" << endl;
	//

	system("pause");
	return 0;
}
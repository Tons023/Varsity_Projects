
public class Beeper 
{
    int score = 0;
    String userID;
    String author;
    int views;
    int numBeeps;
    int numLikes;
    
    public int calculateScore(int score)
    {
        score = (numBeeps + numLikes)*200/views;
        return score;
    }
    
    public String getUserId()
    {
        return userID;
    }
    
    public void setUserId(String newUserID)
    {
        this.userID = newUserID;
    }
    
    public void setAuthor(String newAuthor)
    {
        this.author = newAuthor;
    }
    
    public String getAuthor()
    {
        return author;
    }
    
    public int getViews()
    {
        return views;
    }
    
    public void setViews(int newViews)
    {
        this.views = newViews;
    }
    
    public int getRebeeps()
    {
        return numBeeps;
    }
    
    public void setRebeeps(int newBeeps)
    {
        this.numBeeps = newBeeps;
    }
    
    public int getLikes()
    {
        return numLikes;
    }
    
    public void setLikes(int newLikes)
    {
        this.numLikes = newLikes;
    }
}

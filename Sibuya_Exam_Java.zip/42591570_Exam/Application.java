import java.util.*;
import java.io.*;

public class Application
{
    public static void main(String[] args)
    {
        try
       {
           Beeper Beep = new Beeper();
           DingDong Ding = new DingDong();
           File myfile = new File("postings.txt");
           Scanner myReader = new Scanner(myfile);
           Info[] arrInfo = new Info[25];
           int score = 0;
           int highest = 0;
           Scanner id = new Scanner(System.in);
           Scanner auth = new Scanner(System.in);
           Scanner num = new Scanner(System.in);
           while(myReader.hasNextLine())
           {
               arrInfo = myReader.nextLine();
               //System.out.println(data);
               if(myReader.hasNext(String(0)) == "B")
               {
                   Beeper.userID = id.arrInfo.getString(7);
                   Beeper.auth = author.arrInfo.getStringAt(",")
                   Beeper.view = num.arrInfo.getLineAt(",")
                   Beeper.numBeeps = num.arrInfo.getLineAt(",")
                   Beeper.numLikes = num.arrInfo.getLineAt(",")
                   score = Beeper.calculateScore();
               }
               else if(myReader.hasNext(String(0)) == "D")
               {
                   DingDong.userID = id.arrInfo.getString(7);
                   DingDong.auth = author.arrInfo.getStringAt(",")
                   DingDong.view = num.arrInfo.getLineAt(",")
                   Dingdong.duration = num.arrInfo.getlineAt(",")
                   DingDong.shares = num.arrInfo.getLineAt(",")
                   score = DingDong.calculateScore();
               }
               else
               {    
                   String error = myReader.hasNext();
                   System.out.println("Incorrect code: " + error);
               }
           }
           
           System.out.println("\nList of postings:");
           for(int i =0 ; i < 25; i++)
           {
               printf("%-15s%-15s5-20d%-20d%-20d", arrInfo[userID], arrInfo[author]);
           }
           System.out.println("\nScores of postings:");
           for(int k = 0; k < 25; k++)
           {
               printf("%-15s%-15s%-20d", arrInfo[userID], arrInfo[author], arrInfo[k].score);
           }
           System.out.println("\nDuration of DingDongs:");
           if(myReader.hasNext(String(0)) == "D")
           {
               printf("%-15s%-15s%-20d", arrInfo[DingDong.userID]);
           }
           
           for(int k=0; k < 25; k++)
           {
                if(arrInfo[k].numBeeps < arrInfo[k].numBeeps)
                {
                    int temp = arrInfo[k].numBeeps;
                    highest = temp;
                }
           }
           System.out.println("The Beep that was rebeeped the most times is: " + "with " + highest + "rebeeps");
       }
       catch(IOException e)
       {
           System.out.println("File not found");
       }
       
    }
}

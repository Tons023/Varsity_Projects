import java.lang.Math;
public class DingDong
{
    int score = 0;
    String userID;
    String author;
    int views;
    int duration;
    int shares;
    
    public int calculateScore(int score)
    {
        score = sqrt((shares * views))/duration;
        return score;
    }
    
    public String getUserId()
    {
        return userID;
    }
    
    public void setUserId(String newUserID)
    {
        this.userID = newUserID;
    }
    
    public void setAuthor(String newAuthor)
    {
        this.author = newAuthor;
    }
    
    public String getAuthor()
    {
        return author;
    }
    
    public int getViews()
    {
        return views;
    }
    
    public void setViews(int newViews)
    {
        this.views = newViews;
    }
    
    public int getDuration()
    {
        return duration;
    }
    
    public void setDuration(int newDuration)
    {
        this.duration = newDuration;
    }
    
    public int getShares()
    {
        return views;
    }
    
    public void setShares(int newShares)
    {
        this.shares = newShares;
    }
}


public interface UserInfo implements Beeper, DingDong
{
    public void UserId();
    public String Author();
    public int Views();
    public int Rebeeps();
    public int Likes();
    public int Duration();
    public int Shares();
}

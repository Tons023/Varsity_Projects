 #include <iostream>

using namespace std;

void doWhile_Loop()
{

    char answer;
    int choice;
    int count = 0;
    int KM5_FEE = 65, KM10_FEE = 100, KM15_FEE = 150;

    cout << "\nDo you want to register another participant (Y OR N): ";
    cin >> answer;
    while((answer == 'Y') || (answer == 'y'))
    {
        if((answer == 'Y') || (answer == 'y'))
        {
            cout << "Categories: "
                 << "\n1. 5 Kilometers"
                 << "\n2. 10 Kilometers"
                 << "\n3. 15 Kilometers";
            cout << "\nYour Choice (1/2/3): ";
            cin >> choice;
            switch (choice)
            {
                case 1:

                    break;
                case 2:

                    break;
                case 3:

                    break;
                default:
                    cout << "Invalid Category \nRegistration Cancelled" << endl;
            }

        }
        else
            cout << "Invalid Input \nRegistration Cancelled" << endl;
    cout << "\nDo you want to register another participant (Y OR N): ";
    cin >> answer;
    }

}

int main()
{
    char answer;
    int choice;
    int count;
    int KM5_FEE = 65, KM10_FEE = 100, KM15_FEE = 150;

    cout << "Fun Run Competition!" << endl;

    cout << "Do you want to register a participant (Y OR N): ";
    cin >> answer;
    if((answer == 'Y') || (answer == 'y'))
    {
        cout << "Categories: "
             << "\n1. 5 Kilometers"
             << "\n2. 10 Kilometers"
             << "\n3. 15 Kilometers";
        cout << "\nYour Choice (1/2/3): ";
        cin >> choice;

    }
    else
        cout << "Invalid Input \nRegistration Cancelled" << endl;

    doWhile_Loop();



    cout << "\nRegistration per category:";
    cout << "\nCategory\tNum of Athletes\tIncome"
         << "\n5 Kilometers"
         << "\n10 Kilometers"
         << "\n15 Kilometers\n";

    cout << "\nTotal number of participants: "
         << "\nTotal Income: "
         << "\nCategory with highest income: ";

    return 0;
}

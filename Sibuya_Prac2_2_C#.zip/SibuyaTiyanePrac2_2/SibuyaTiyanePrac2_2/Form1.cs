﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SibuyaTiyanePrac2_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnShow2_Click(object sender, EventArgs e)
        {
            lblText2.Text = "TextBooks for second years can be collected from Mr Dimitri Keykaan.";
        }

        private void btnShow3_Click(object sender, EventArgs e)
        {
            lblText2.Text = "TextBooks for third years can be collected from Mr Ricus Warmenhoven.";
        }

        private void btnShow1_Click(object sender, EventArgs e)
        {
            lblText2.Text = "TextBooks for first years can be collected from Mr Luke Coetzee.";
        }
    }
}

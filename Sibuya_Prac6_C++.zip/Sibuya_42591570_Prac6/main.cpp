#include <iostream>

using namespace std;

void displayData(int* pArrRain, int* pCounter)
{
    cout << "#Month  Rainfall figures(mm)" << endl;
    for(int i = 0; i <*pCounter; i++)
    {
        cout << i+1 << "\t" << *(pArrRain+i) <<  endl;
    }
}

void calcAve(int* pArrRain, int* pCounter, double* pAve)
{
    for(int i = 0; i <* pCounter; i++)
    {
        *pAve += *(pArrRain+i);
    }
    *pAve = *pAve/(*pCounter);
}

void findHighestRainfall(int* pArrRain, int* pCounter, int* pHighest)
{
    *pHighest = *pArrRain;
    for(int i = 0; i <* pCounter; i++)
    {
        if(*pHighest <* (pArrRain+i))
        {
            *pHighest =*(pArrRain+i);
        }
    }

}
int main()
{
    int counter = 12;
    int ArrRain[counter] = {234, 325, 287, 112, 16, 0, 0, 0, 45, 123, 224, 204};
    int Highest;
    double ave;

    double* pAve = &ave;
    int* pHighest = &Highest;
    int* pCounter = &counter;
    int* pArrRain = ArrRain;

    displayData(pArrRain, pCounter);
    calcAve(pArrRain, pCounter, pAve);
    findHighestRainfall(pArrRain, pCounter, pHighest);

    cout << "\nThe average rainfall is " << *pAve << endl;
    cout << "The highest rainfall figure is " << *pHighest << endl;

    return 0;
}

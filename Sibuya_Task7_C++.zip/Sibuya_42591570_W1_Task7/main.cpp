#include <iostream>

using namespace std;

int main()
{
    char input = ' ';

    cout << "Enter a character (letter or a digit): ";
    cin >> input;

    if(input => 65 && input <=90)
    {
        cout << "\nYou entered the uppercase letter " << input << endl;
    }
    else if(input >= 97 && input <= 122)
    {
        cout << "\nYou entered the lowercase letter " << input << endl;
    }
    else if(input >= 48 && input <=57)
    {
        cout << "\nYou entered the digit " << input << endl;
    }
    else
    {
        cout << "\nYou have entered a special character " << endl;
    }



    return 0;
}

import java.util.Scanner;

public class DigitSum 
{
    public static void main(String[] args) 
    {
        // Request user to enter a six digit integer value
        Scanner input = new Scanner(System.in);
        
        char answer;
    do{
        int sum = 0;
        System.out.print("Please enter a six digit integer value: ");
        int num = input.nextInt();

        // Add the separate digits to get the total value (sum) of all the digits
        
        String numStr = Integer.toString(num);
        for (int i = 0; i < numStr.length(); i++) 
        {
            sum += Character.getNumericValue(numStr.charAt(i));
        }

        // Display the sum of the digits
        System.out.println("The sum of the digits is: " + sum);

        // Use the % operator to extract the second digit from the left,
        // and use the / operator to remove the extracted digit
        int secondDigitFromLeft = (num / 1000) % 10;
        int newNum = num / 10000 * 1000 + num % 1000;
        System.out.println("The second digit from the left is: " + secondDigitFromLeft);
        System.out.println("The number with the second digit extracted: " + newNum);
        // Add the digits of the new number to get the total sum
        int newTotalSum = 0;
        String newNumStr = Integer.toString(newNum);
        for (int i = 0; i < newNumStr.length(); i++) {
            newTotalSum += Character.getNumericValue(newNumStr.charAt(i));
        }

        // Display the total sum
        System.out.println("The total sum is: " + (sum + newTotalSum));
        System.out.print("Do you still want to continue(Y/N): ");
        answer = input.next().charAt(0);
        System.out.println();
    }
    while(answer != 'N');
    }
}

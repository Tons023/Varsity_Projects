import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.*;
import java.awt.event.*;


public class MyObjects extends  JFrame {

    public ItemList theList = new ItemList();
    public ItemList soldList = new ItemList();
    public double totalSale = 0;

    /**
     * Creates new form Item
     */
    public MyObjects() {

        initComponents();
        AddingItems.setVisible(false);
        Selling.setVisible(true);
        panel3.setVisible(false);
        ItemsPanel.setVisible(false);
    }

   
    @SuppressWarnings("unchecked")
    
    private void initComponents() {

        AddingItems = new  JPanel();
        lblName = new  JLabel();
        lblItemNum = new  JLabel();
        lblQTY = new  JLabel();
        lblPrice = new  JLabel();
        txtPrice = new  JTextField();
        txtQTY = new  JTextField();
        txtNumber = new  JTextField();
        txtName = new  JTextField();
        btnNew = new  JButton();
        btnSave = new  JButton();
        btnBack = new  JButton();
        btnExit = new  JButton();
        Selling = new  JPanel();
        btnPurchase = new  JButton();
        btnStock = new  JButton();
          btnSTotal = new  JButton();
        lblShowBill = new  JLabel();
        btnDelete = new  JButton();
        btnItem = new  JButton();
        btnShow = new  JButton();
        lblShopName = new  JLabel();
        Sold = new  JButton();
        btn5 = new  JButton();
        panel3 = new  JPanel();
        btnHome = new  JButton();
        jScrollPane2 = new  JScrollPane();
        tbData = new  JTable();
        ItemsPanel = new  JPanel();
        lblReceipt = new  JLabel();
        lblPurchase = new  JLabel();
        lblItem1 = new  JLabel();
        qtLabel1 = new  JLabel();
        pLabel1 = new  JLabel();
        lblSubTotal7 = new  JLabel();
        lblSubTotal1 = new  JLabel();
        p1Label1 = new  JLabel();
        qt1Label1 = new  JLabel();
        lblItem2 = new  JLabel();
        qt2Label2 = new  JLabel();
        qt3Label2 = new  JLabel();
        lblItem3 = new  JLabel();
        qt3Label3 = new  JLabel();
        qt2Label3 = new  JLabel();
        lblSubTotal2 = new  JLabel();
        lblSubTotal3 = new  JLabel();
        qt4Label2 = new  JLabel();
        lblSubTotal4 = new  JLabel();
        lblSubTotal5 = new  JLabel();
        lblSubTotal6 = new  JLabel();
        jSeparator2 = new  JSeparator();
        lblBill = new  JLabel();
        lblTotalBill = new  JLabel();
        qt6Label2 = new  JLabel();
        qt5Label2 = new  JLabel();
        qt4Label3 = new  JLabel();
        qt5Label3 = new  JLabel();
        qt6Label3 = new  JLabel();
        lblItem6 = new  JLabel();
        lblItem5 = new  JLabel();
        lblItem4 = new  JLabel();

        setDefaultCloseOperation( WindowConstants.EXIT_ON_CLOSE);
        setTitle("My Shop Point of Sale");
        setResizable(false);

        AddingItems.setFocusable(false);
        AddingItems.setMaximumSize(new java.awt.Dimension(360, 260));
        AddingItems.setRequestFocusEnabled(false);

        lblName.setText("Name:");

        lblItemNum.setText("Item Number:");

        lblQTY.setText("Quantity:");

        lblPrice.setText("Price:");

        txtPrice.addActionListener(new   ActionListener() {
            public void actionPerformed(  ActionEvent e) {
                txtPriceActionPerformed(e);
            }
        });
        txtPrice.addKeyListener(new   KeyAdapter() {
            public void keyTyped(  KeyEvent e) {
                txtPriceKeyTyped(e);
            }
        });

        txtQTY.addActionListener(new   ActionListener() {
            public void actionPerformed(  ActionEvent e) {
               
            }
        });
        txtQTY.addKeyListener(new   KeyAdapter() {
            public void keyTyped(  KeyEvent e) {
                txtQTYKeyTyped(e);
            }
        });

        txtNumber.addFocusListener(new   FocusAdapter() {
            public void focusLost(  FocusEvent e) {
                txtNumberFocusLost(e);
            }
        });
        txtNumber.addActionListener(new   ActionListener() {
            public void actionPerformed(  ActionEvent e) {
                txtNumberActionPerformed(e);
            }
        });
        txtNumber.addKeyListener(new   KeyAdapter() {
            public void keyTyped(  KeyEvent e) {
                txtNumberKeyTyped(e);
            }
        });

        txtName.addActionListener(new   ActionListener() {
            public void actionPerformed(  ActionEvent e) {
                txtNameActionPerformed(e);
            }
        });
        txtName.addKeyListener(new   KeyAdapter() {
            public void keyTyped(  KeyEvent e) {
                txtNameKeyTyped(e);
            }
        });

        btnNew.setText("New");
        btnNew.addActionListener(new   ActionListener() {
            public void actionPerformed(  ActionEvent e) {
                btnNewActionPerformed(e);
            }
        });

        btnSave.setText("Save");
        btnSave.addActionListener(new   ActionListener() {
            public void actionPerformed(  ActionEvent e) {
                btnSaveActionPerformed(e);
            }
        });

        btnBack.setText("Back");
        btnBack.addActionListener(new   ActionListener() {
            public void actionPerformed(  ActionEvent e) {
                btnBackActionPerformed(e);
            }
        });

        btnExit.setText("Exit");
        btnExit.addActionListener(new   ActionListener() {
            public void actionPerformed(  ActionEvent e) {
                btnExitActionPerformed(e);
            }
        });

         GroupLayout AddingItemsLayout = new  GroupLayout(AddingItems);
        AddingItems.setLayout(AddingItemsLayout);
        AddingItemsLayout.setHorizontalGroup(AddingItemsLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                                        .addGroup(AddingItemsLayout.createSequentialGroup()
                                        .addGroup(AddingItemsLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                                        .addGroup(AddingItemsLayout.createSequentialGroup()
                                        .addContainerGap()
                                        .addGroup(AddingItemsLayout.createParallelGroup()
                                        .addComponent(lblName)
                                        .addComponent(lblItemNum)
                                        .addComponent(lblQTY)
                                        .addComponent(lblPrice))
                                        .addGap(69, 69, 69)
                                        .addGroup(AddingItemsLayout.createParallelGroup( GroupLayout.Alignment.LEADING)
                                        .addComponent(txtPrice,  GroupLayout.PREFERRED_SIZE, 130,  GroupLayout.PREFERRED_SIZE)
                                        .addComponent(txtQTY,  GroupLayout.PREFERRED_SIZE, 130,  GroupLayout.PREFERRED_SIZE)
                                        .addComponent(txtNumber,  GroupLayout.PREFERRED_SIZE, 130,  GroupLayout.PREFERRED_SIZE)
                                        .addComponent(txtName,  GroupLayout.PREFERRED_SIZE, 130,  GroupLayout.PREFERRED_SIZE)))
                                        .addGroup(AddingItemsLayout.createSequentialGroup()
                                        .addGap(23, 23, 23)
                                        .addComponent(btnNew)
                                        .addGap(23, 23, 23)
                                        .addComponent(btnSave)
                                        .addGap(23, 23, 23)
                                        .addComponent(btnBack)
                                        .addGap(23, 23, 23)
                                        .addComponent(btnExit,  GroupLayout.PREFERRED_SIZE, 73,  GroupLayout.PREFERRED_SIZE)))
                                        .addContainerGap(72, Short.MAX_VALUE)));
        AddingItemsLayout.setVerticalGroup(AddingItemsLayout.createParallelGroup( GroupLayout.Alignment.LEADING)
                                      .addGroup(AddingItemsLayout.createSequentialGroup()
                                      .addContainerGap()
                                      .addGroup(AddingItemsLayout.createParallelGroup( GroupLayout.Alignment.BASELINE)
                                      .addComponent(lblName,  GroupLayout.PREFERRED_SIZE, 30,  GroupLayout.PREFERRED_SIZE)
                                      .addComponent(txtName,  GroupLayout.PREFERRED_SIZE, 30,  GroupLayout.PREFERRED_SIZE))
                                      .addPreferredGap( LayoutStyle.ComponentPlacement.UNRELATED)
                                      .addGroup(AddingItemsLayout.createParallelGroup( GroupLayout.Alignment.BASELINE)
                                      .addComponent(lblItemNum,  GroupLayout.PREFERRED_SIZE, 30,  GroupLayout.PREFERRED_SIZE)
                                      .addComponent(txtNumber,  GroupLayout.PREFERRED_SIZE, 30,  GroupLayout.PREFERRED_SIZE))
                                      .addPreferredGap( LayoutStyle.ComponentPlacement.RELATED)
                                      .addGroup(AddingItemsLayout.createParallelGroup( GroupLayout.Alignment.BASELINE)
                                      .addComponent(lblQTY,  GroupLayout.PREFERRED_SIZE, 30,  GroupLayout.PREFERRED_SIZE)
                                      .addComponent(txtQTY,  GroupLayout.PREFERRED_SIZE, 30,  GroupLayout.PREFERRED_SIZE))
                                      .addPreferredGap( LayoutStyle.ComponentPlacement.RELATED)
                                      .addGroup(AddingItemsLayout.createParallelGroup( GroupLayout.Alignment.BASELINE)
                                      .addComponent(lblPrice,  GroupLayout.PREFERRED_SIZE, 31,  GroupLayout.PREFERRED_SIZE)
                                      .addComponent(txtPrice,  GroupLayout.PREFERRED_SIZE, 30,  GroupLayout.PREFERRED_SIZE))
                                      .addGap(23, 23, 23).addGroup(AddingItemsLayout.createParallelGroup( GroupLayout.Alignment.BASELINE)
                                      .addComponent(btnSave).addComponent(btnBack).addComponent(btnNew).addComponent(btnExit))
                                      .addContainerGap(268, Short.MAX_VALUE)));

        Selling.setFocusable(false);
        

        btnPurchase.setText("Purchase");
        btnPurchase.setFocusPainted(false);
        btnPurchase.setFocusable(false);
        btnPurchase.addActionListener(new   ActionListener() {
            public void actionPerformed(  ActionEvent e) {
                btnPurchaseActionPerformed(e);
            }
        });

        btnStock.setText("Add Stock");
        btnStock.addActionListener(new   ActionListener() {
            public void actionPerformed(  ActionEvent e) {
                btnStockActionPerformed(e);
            }
        });

          btnSTotal.setText("Total Sale");
          btnSTotal.addActionListener(new   ActionListener() {
            public void actionPerformed(  ActionEvent e) {
                  btnSTotalActionPerformed(e);
            }
        });

        btnDelete.setText("Delete Item");
        
        btnDelete.addActionListener(new   ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                btnDeleteActionPerformed(e);
            }
        });

        btnItem.setText("Add Item");
        btnItem.addActionListener(new   ActionListener() {
            public void actionPerformed(  ActionEvent e) {
                btnItemActionPerformed(e);
            }
        });

        btnShow.setText("Show Items");
        btnShow.addActionListener(new   ActionListener() {
            public void actionPerformed(  ActionEvent e) {
                btnShowActionPerformed(e);
            }
        });

        lblShopName.setText("Simple Point of Sale");

        Sold.setText("Sold Items");
        Sold.addActionListener(new   ActionListener() {
            public void actionPerformed(  ActionEvent e) {
                SoldActionPerformed(e);
            }
        });

        btn5.setText("Exit");
        btn5.addActionListener(new   ActionListener() {
            public void actionPerformed(  ActionEvent e) {
                btn5ActionPerformed(e);
            }
        });

         GroupLayout SellingLayout = new  GroupLayout(Selling);
        Selling.setLayout(SellingLayout);
        SellingLayout.setHorizontalGroup(
            SellingLayout.createParallelGroup( GroupLayout.Alignment.LEADING)
            .addGroup( GroupLayout.Alignment.TRAILING, SellingLayout.createSequentialGroup()
                .addContainerGap(30, Short.MAX_VALUE)
                .addComponent(lblShopName,  GroupLayout.PREFERRED_SIZE, 356,  GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30))
            .addGroup(SellingLayout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addGroup(SellingLayout.createParallelGroup( GroupLayout.Alignment.TRAILING)
                    .addGroup(SellingLayout.createSequentialGroup()
                        .addGroup(SellingLayout.createParallelGroup( GroupLayout.Alignment.LEADING)
                            .addGroup(SellingLayout.createSequentialGroup()
                                .addComponent(btnStock)
                                .addGap(23, 23, 23)
                                .addComponent(btnPurchase))
                            .addComponent(lblShowBill,  GroupLayout.PREFERRED_SIZE, 141,  GroupLayout.PREFERRED_SIZE))
                        .addGap(23, 23, 23)
                        .addComponent(  btnSTotal))
                    .addGroup(SellingLayout.createSequentialGroup()
                        .addGroup(SellingLayout.createParallelGroup( GroupLayout.Alignment.LEADING)
                            .addGroup(SellingLayout.createSequentialGroup()
                                .addComponent(btnItem)
                                .addGap(23, 23, 23)
                                .addComponent(btnDelete))
                            .addComponent(Sold))
                        .addGap(23, 23, 23)
                        .addGroup(SellingLayout.createParallelGroup( GroupLayout.Alignment.TRAILING)
                            .addComponent(btnShow)
                            .addComponent(btn5))))
                .addContainerGap( GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        SellingLayout.linkSize( SwingConstants.HORIZONTAL, new java.awt.Component[] {btnItem, btnDelete, btnShow, btnPurchase, btnStock,   btnSTotal});

        SellingLayout.linkSize( SwingConstants.HORIZONTAL, new java.awt.Component[] {Sold, btn5});

        SellingLayout.setVerticalGroup(
            SellingLayout.createParallelGroup( GroupLayout.Alignment.LEADING)
            .addGroup(SellingLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblShopName,  GroupLayout.PREFERRED_SIZE, 29,  GroupLayout.PREFERRED_SIZE)
                .addGap(31, 31, 31)
                .addGroup(SellingLayout.createParallelGroup( GroupLayout.Alignment.BASELINE)
                    .addComponent(btnStock)
                    .addComponent(btnPurchase)
                    .addComponent(  btnSTotal))
                .addGap(23, 23, 23)
                .addComponent(lblShowBill,  GroupLayout.PREFERRED_SIZE, 34,  GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26)
                .addGroup(SellingLayout.createParallelGroup( GroupLayout.Alignment.BASELINE)
                    .addComponent(btnShow)
                    .addComponent(btnDelete)
                    .addComponent(btnItem))
                .addPreferredGap( LayoutStyle.ComponentPlacement.RELATED, 58, Short.MAX_VALUE)
                .addGroup(SellingLayout.createParallelGroup( GroupLayout.Alignment.BASELINE)
                    .addComponent(Sold)
                    .addComponent(btn5))
                .addGap(26, 26, 26))
        );

        SellingLayout.linkSize( SwingConstants.VERTICAL, new java.awt.Component[] {btnItem, btnDelete, btnShow, btnPurchase, btnStock,   btnSTotal});

        btnHome.setText("Home Page");
        btnHome.addActionListener(new   ActionListener() {
            public void actionPerformed(  ActionEvent e) {
                btnHomeActionPerformed(e);
            }
        });

        tbData.setModel(new  DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Item Number", "Item Name", "Quantity", "Price"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jScrollPane2.setViewportView(tbData);

         GroupLayout panel3Layout = new  GroupLayout(panel3);
        panel3.setLayout(panel3Layout);
        panel3Layout.setHorizontalGroup(
            panel3Layout.createParallelGroup( GroupLayout.Alignment.LEADING)
            .addGroup(panel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnHome)
                .addContainerGap(219, Short.MAX_VALUE))
            .addComponent(jScrollPane2,  GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
        );
        panel3Layout.setVerticalGroup(
            panel3Layout.createParallelGroup( GroupLayout.Alignment.LEADING)
            .addGroup(panel3Layout.createSequentialGroup()
                .addComponent(jScrollPane2,  GroupLayout.PREFERRED_SIZE, 403,  GroupLayout.PREFERRED_SIZE)
                .addGap(13, 13, 13)
                .addComponent(btnHome)
                .addContainerGap( GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        lblReceipt.setText("                                                    Receipt");
        lblReceipt.setBorder( BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        lblPurchase.setText("Items Purchased");

        lblItem1.setText("it1");

        qtLabel1.setText("Quantity");

        pLabel1.setText("Price");

        lblSubTotal7.setText("Sub Total");

        lblSubTotal1.setText("it1");

        p1Label1.setText("it1");

        qt1Label1.setText("it1");

        lblItem2.setText("it2");

        qt2Label2.setText("it2");

        qt3Label2.setText("it3");

        lblItem3.setText("it3");

        qt3Label3.setText("it3");

        qt2Label3.setText("it2");

        lblSubTotal2.setText("it2");

        lblSubTotal3.setText("it3");

        qt4Label2.setText("it4");

        lblSubTotal4.setText("it4");

        lblSubTotal5.setText("it5");

        lblSubTotal6.setText("it6");

        lblBill.setText("Total Bill:");

        lblTotalBill.setText("tb");

        qt6Label2.setText("it6");

        qt5Label2.setText("it5");

        qt4Label3.setText("it4");

        qt5Label3.setText("it5");

        qt6Label3.setText("it6");

        lblItem6.setText("it6");

        lblItem5.setText("it5");

        lblItem4.setText("it4");

         GroupLayout ItemsPanelLayout = new  GroupLayout(ItemsPanel);
        ItemsPanel.setLayout(ItemsPanelLayout);
        ItemsPanelLayout.setHorizontalGroup(
            ItemsPanelLayout.createParallelGroup( GroupLayout.Alignment.LEADING).addGroup(ItemsPanelLayout.createSequentialGroup()
                    .addGap(35, 35, 35)
                    .addGroup(ItemsPanelLayout.createParallelGroup( GroupLayout.Alignment.LEADING, false)
                    .addComponent(lblItem2,  GroupLayout.DEFAULT_SIZE,  GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblPurchase,  GroupLayout.DEFAULT_SIZE, 101, Short.MAX_VALUE)
                    .addComponent(lblItem1,  GroupLayout.DEFAULT_SIZE,  GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblItem3,  GroupLayout.DEFAULT_SIZE,  GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblItem4,  GroupLayout.DEFAULT_SIZE,  GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblItem5,  GroupLayout.Alignment.TRAILING,  GroupLayout.DEFAULT_SIZE,  GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblItem6,  GroupLayout.Alignment.TRAILING,  GroupLayout.DEFAULT_SIZE,  GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGap(23, 23, 23)
                    .addGroup(ItemsPanelLayout.createParallelGroup( GroupLayout.Alignment.LEADING)
                    .addComponent(qtLabel1,  GroupLayout.PREFERRED_SIZE, 71,  GroupLayout.PREFERRED_SIZE)
                    .addComponent(qt5Label3,  GroupLayout.DEFAULT_SIZE,  GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(qt4Label3,  GroupLayout.DEFAULT_SIZE,  GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(qt3Label2,  GroupLayout.DEFAULT_SIZE,  GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(qt2Label2,  GroupLayout.PREFERRED_SIZE, 24,  GroupLayout.PREFERRED_SIZE)
                    .addComponent(qt6Label3,  GroupLayout.PREFERRED_SIZE, 34,  GroupLayout.PREFERRED_SIZE)
                    .addComponent(qt1Label1,  GroupLayout.PREFERRED_SIZE, 45,  GroupLayout.PREFERRED_SIZE))
                    .addGap(23, 23, 23)
                    .addGroup(ItemsPanelLayout.createParallelGroup( GroupLayout.Alignment.LEADING, false)
                    .addComponent(pLabel1,  GroupLayout.DEFAULT_SIZE, 65, Short.MAX_VALUE)
                    .addComponent(p1Label1,  GroupLayout.DEFAULT_SIZE,  GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(qt2Label3,  GroupLayout.DEFAULT_SIZE,  GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(qt3Label3,  GroupLayout.DEFAULT_SIZE,  GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(qt4Label2,  GroupLayout.DEFAULT_SIZE,  GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(qt5Label2,  GroupLayout.DEFAULT_SIZE,  GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(qt6Label2,  GroupLayout.DEFAULT_SIZE,  GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addPreferredGap( LayoutStyle.ComponentPlacement.RELATED)
                    .addGroup(ItemsPanelLayout.createParallelGroup( GroupLayout.Alignment.LEADING)
                    .addGroup(ItemsPanelLayout.createSequentialGroup()
                    .addGroup(ItemsPanelLayout.createParallelGroup( GroupLayout.Alignment.LEADING, false)
                    .addComponent(lblSubTotal3,  GroupLayout.DEFAULT_SIZE,  GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblSubTotal4,  GroupLayout.DEFAULT_SIZE,  GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblSubTotal5,  GroupLayout.DEFAULT_SIZE,  GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblSubTotal2,  GroupLayout.DEFAULT_SIZE, 65, Short.MAX_VALUE)
                    .addComponent(lblSubTotal6,  GroupLayout.DEFAULT_SIZE,  GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addContainerGap( GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(ItemsPanelLayout.createSequentialGroup()
                    .addGroup(ItemsPanelLayout.createParallelGroup( GroupLayout.Alignment.TRAILING)
                    .addComponent(lblSubTotal1,  GroupLayout.Alignment.LEADING,  GroupLayout.DEFAULT_SIZE,  GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblSubTotal7,  GroupLayout.DEFAULT_SIZE, 68, Short.MAX_VALUE))
                    .addGap(21, 21, 21))))
                    .addGroup(ItemsPanelLayout.createSequentialGroup()
                    .addContainerGap()
                    .addGroup(ItemsPanelLayout.createParallelGroup( GroupLayout.Alignment.LEADING)
                    .addComponent(lblReceipt,  GroupLayout.DEFAULT_SIZE,  GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jSeparator2))
                    .addContainerGap())
                    .addGroup(ItemsPanelLayout.createSequentialGroup()
                    .addGap(168, 168, 168)
                    .addComponent(lblBill,  GroupLayout.PREFERRED_SIZE, 67,  GroupLayout.PREFERRED_SIZE)
                    .addGap(23, 23, 23)
                    .addComponent(lblTotalBill,  GroupLayout.PREFERRED_SIZE, 114,  GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)));
                    
        ItemsPanelLayout.setVerticalGroup(ItemsPanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                    .addGroup(ItemsPanelLayout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(lblReceipt,GroupLayout.PREFERRED_SIZE, 47,GroupLayout.PREFERRED_SIZE)
                    .addGap(23, 23, 23)
                    .addGroup(ItemsPanelLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(lblPurchase)
                    .addComponent(qtLabel1)
                    .addComponent(pLabel1)
                    .addComponent(lblSubTotal7))
                    .addPreferredGap( LayoutStyle.ComponentPlacement.UNRELATED)
                    .addGroup(ItemsPanelLayout.createParallelGroup( GroupLayout.Alignment.LEADING)
                    .addGroup(ItemsPanelLayout.createParallelGroup( GroupLayout.Alignment.LEADING)
                    .addGroup(ItemsPanelLayout.createSequentialGroup()
                    .addComponent(lblItem1,  GroupLayout.PREFERRED_SIZE, 30,  GroupLayout.PREFERRED_SIZE)
                    .addGap(23, 23, 23)
                    .addComponent(lblItem2,  GroupLayout.PREFERRED_SIZE, 30,  GroupLayout.PREFERRED_SIZE)
                    .addGap(23, 23, 23)
                    .addComponent(lblItem3,  GroupLayout.PREFERRED_SIZE, 30,  GroupLayout.PREFERRED_SIZE)
                    .addGap(23, 23, 23)
                            .addComponent(lblItem4,  GroupLayout.PREFERRED_SIZE, 30,  GroupLayout.PREFERRED_SIZE)
                            .addGap(23, 23, 23)
                            .addComponent(lblItem5,  GroupLayout.PREFERRED_SIZE, 30,  GroupLayout.PREFERRED_SIZE)
                            .addGap(23, 23, 23)
                            .addComponent(lblItem6,  GroupLayout.PREFERRED_SIZE, 30,  GroupLayout.PREFERRED_SIZE))
                            .addGroup( GroupLayout.Alignment.TRAILING, ItemsPanelLayout.createSequentialGroup()
                            .addComponent(qt1Label1,  GroupLayout.PREFERRED_SIZE, 30,  GroupLayout.PREFERRED_SIZE)
                            .addGap(23, 23, 23)
                            .addComponent(qt2Label2,  GroupLayout.PREFERRED_SIZE, 30,  GroupLayout.PREFERRED_SIZE)
                            .addGap(23, 23, 23)
                            .addComponent(qt3Label2,  GroupLayout.PREFERRED_SIZE, 30,  GroupLayout.PREFERRED_SIZE)
                            .addGap(23, 23, 23)
                            .addComponent(qt4Label3,  GroupLayout.PREFERRED_SIZE, 30,  GroupLayout.PREFERRED_SIZE)
                            .addGap(23, 23, 23)
                            .addComponent(qt5Label3,  GroupLayout.PREFERRED_SIZE, 30,  GroupLayout.PREFERRED_SIZE)
                            .addGap(23, 23, 23)
                            .addComponent(qt6Label3,  GroupLayout.PREFERRED_SIZE, 30,  GroupLayout.PREFERRED_SIZE)))
                            .addGroup(ItemsPanelLayout.createSequentialGroup()
                        .addComponent(p1Label1,  GroupLayout.PREFERRED_SIZE, 30,  GroupLayout.PREFERRED_SIZE)
                        .addGap(23, 23, 23)
                        .addComponent(qt2Label3,  GroupLayout.PREFERRED_SIZE, 30,  GroupLayout.PREFERRED_SIZE)
                        .addGap(23, 23, 23)
                        .addComponent(qt3Label3,  GroupLayout.PREFERRED_SIZE, 30,  GroupLayout.PREFERRED_SIZE)
                        .addGap(23, 23, 23)
                        .addComponent(qt4Label2,  GroupLayout.PREFERRED_SIZE, 30,  GroupLayout.PREFERRED_SIZE)
                        .addGap(23, 23, 23)
                        .addComponent(qt5Label2,  GroupLayout.PREFERRED_SIZE, 30,  GroupLayout.PREFERRED_SIZE)
                        .addGap(23, 23, 23)
                        .addComponent(qt6Label2,  GroupLayout.PREFERRED_SIZE, 30,  GroupLayout.PREFERRED_SIZE))
                        .addGroup(ItemsPanelLayout.createSequentialGroup()
                        .addComponent(lblSubTotal1,  GroupLayout.PREFERRED_SIZE, 30,  GroupLayout.PREFERRED_SIZE)
                        .addGap(23, 23, 23)
                        .addComponent(lblSubTotal2,  GroupLayout.PREFERRED_SIZE, 30,  GroupLayout.PREFERRED_SIZE)
                        .addGap(23, 23, 23)
                        .addComponent(lblSubTotal3,  GroupLayout.PREFERRED_SIZE, 30,  GroupLayout.PREFERRED_SIZE)
                        .addGap(23, 23, 23)
                        .addComponent(lblSubTotal4,  GroupLayout.PREFERRED_SIZE, 30,  GroupLayout.PREFERRED_SIZE)
                        .addGap(23, 23, 23)
                        .addComponent(lblSubTotal5,  GroupLayout.PREFERRED_SIZE, 30,  GroupLayout.PREFERRED_SIZE)
                        .addGap(23, 23, 23)
                        .addComponent(lblSubTotal6,  GroupLayout.PREFERRED_SIZE, 30,  GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap( LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jSeparator2,  GroupLayout.PREFERRED_SIZE, 10,  GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap( LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(ItemsPanelLayout.createParallelGroup( GroupLayout.Alignment.LEADING, false)
                        .addComponent(lblBill,  GroupLayout.PREFERRED_SIZE, 30,  GroupLayout.PREFERRED_SIZE)
                        .addGroup(ItemsPanelLayout.createSequentialGroup()
                        .addComponent(lblTotalBill,  GroupLayout.DEFAULT_SIZE,  GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(5, 5, 5)))
                        .addContainerGap( GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)));

         GroupLayout layout = new  GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup( GroupLayout.Alignment.LEADING)
            .addComponent(AddingItems,  GroupLayout.DEFAULT_SIZE,  GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup( GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(Selling,  GroupLayout.PREFERRED_SIZE,  GroupLayout.DEFAULT_SIZE,  GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(layout.createParallelGroup( GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(panel3,  GroupLayout.PREFERRED_SIZE,  GroupLayout.DEFAULT_SIZE,  GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(layout.createParallelGroup( GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(ItemsPanel,  GroupLayout.PREFERRED_SIZE,  GroupLayout.DEFAULT_SIZE,  GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup( GroupLayout.Alignment.LEADING)
            .addComponent(AddingItems,  GroupLayout.DEFAULT_SIZE,  GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup( GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(Selling,  GroupLayout.PREFERRED_SIZE,  GroupLayout.DEFAULT_SIZE,  GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(layout.createParallelGroup( GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(panel3,  GroupLayout.PREFERRED_SIZE,  GroupLayout.DEFAULT_SIZE,  GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(layout.createParallelGroup( GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(ItemsPanel,  GroupLayout.PREFERRED_SIZE,  GroupLayout.DEFAULT_SIZE,  GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        pack();
    }

    private void txtPriceActionPerformed(  ActionEvent e) {

    }

    

    private void txtNumberActionPerformed(  ActionEvent e) {

    }

    private void txtNameActionPerformed(  ActionEvent e) {

    }
    public void reset() {
        txtName.setText("");
        txtNumber.setText("");
        txtQTY.setText("");
        txtPrice.setText("");
        txtName.requestFocus();
    }
    private void btnNewActionPerformed(  ActionEvent e) {
        reset();
    }


    private void btnSaveActionPerformed(  ActionEvent e) {
        String name;
        int itemNumber;
        int qty;
        double price;
        name = txtName.getText();
        itemNumber = Integer.parseInt(txtNumber.getText());
        qty = Integer.parseInt(txtQTY.getText());
        price = Double.parseDouble(txtPrice.getText());

        Item current = theList.first;
        while (current != null) {
            if (itemNumber == current.itemNumber) {
                JOptionPane.showMessageDialog(this, "This Item Number Already Exist in the List.");
                return;
            }
            break;
        }

        if (price < 0) {
            JOptionPane.showMessageDialog(null, "Price can not be in negative.");
            return;
        } else if (qty < 0) {
            JOptionPane.showMessageDialog(null, "Quantity can not be in negative.");
            return;
        } else {
            theList.insertFirst(name, itemNumber, qty, price);
            JOptionPane.showMessageDialog(null, "Item saved");
        }

        reset();
    }

    private void btnBackActionPerformed(  ActionEvent e) {
        AddingItems.setVisible(false);
        Selling.setVisible(true);
        panel3.setVisible(false);
        ItemsPanel.setVisible(false);
    }
    private void btnExitActionPerformed(  ActionEvent e) {
        System.exit(0);
    }

    private void txtNumberFocusLost(  FocusEvent e) {
        // TODO add your handling code here:

    }
    double totalBill = 0;
    private void btnPurchaseActionPerformed(  ActionEvent e) {
        
        int itNum, qty;
        double total = 0;
        AddingItems.hide();
        panel3.hide();
        Selling.setVisible(true);
        try {
            String input = JOptionPane.showInputDialog("Enter Item Number:");
            itNum = Integer.parseInt(input);
            String input1 = JOptionPane.showInputDialog("Enter Quantity:");
            qty = Integer.parseInt(input1);

            if (theList.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Sorry! Item list is empty.");
                return;
            }
            int a = JOptionPane.showConfirmDialog(null, "Want to purchase more items?");

            if (a == JOptionPane.YES_OPTION) {
                this.btnPurchaseActionPerformed(e);
                
                
            } else if (a == JOptionPane.CANCEL_OPTION) {
                return;
            }
            

            if (qty > theList.find(itNum).qty) {
                JOptionPane.showMessageDialog(null, "Sorry! Item is out of Stock");
                return;
            } else if (itNum != theList.find(itNum).itemNumber) {
                JOptionPane.showMessageDialog(this, "Sorry! Item is not in the List.");
                return;
            } else {
                theList.find(itNum).qty -= qty;
                total += theList.find(itNum).price * qty;
                totalSale += total;
                totalBill+=total;
            }
            lblShowBill.setText("Total Bill is: " + total);
            if(a != 2){
                soldList.insertFirst(theList.find(itNum).name, itNum, qty, theList.find(itNum).price*qty);
            }
            
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Sorry! Item is not in the List.");
        }
    }

    private void btnStockActionPerformed(  ActionEvent e) {
        // TODO add your handling code here:
        int itNum, qty;

        try {
            String input = JOptionPane.showInputDialog("Enter Item Number:");
            itNum = Integer.parseInt(input);
            String input1 = JOptionPane.showInputDialog("Enter Quantity:");
            qty = Integer.parseInt(input1);
            if (theList.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Item List is empty.!");
            } else {
                theList.find(itNum).qty += qty;
                JOptionPane.showMessageDialog(this, "Stock Added!");
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, ex);
        }
    }

    private void   btnSTotalActionPerformed(  ActionEvent e) {
        // TODO add your handling code here:
        lblShowBill.setText("Total Sale is: " + totalSale);
    }

    private void btnDeleteActionPerformed(  ActionEvent e) {
        // TODO add your handling code here:
        int itNum;
        try {
            String input = JOptionPane.showInputDialog("Enter Item Number:");
            itNum = Integer.parseInt(input);
            if (theList.isEmpty()) {
                JOptionPane.showMessageDialog(this, "List is empty!");
            } else {
                int it = theList.find(itNum).itemNumber;
                if (it == itNum) {
                    theList.delete(it);
                    JOptionPane.showMessageDialog(this, "Item Deleted!");
                } else {
                    JOptionPane.showMessageDialog(this, "Invalid Item Number!");
                }
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Invalid Item Number!");
        }
    }

    private void btnShowActionPerformed(  ActionEvent e) {
        if (theList.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Item List is empty.!");
        } else {
            AddingItems.setVisible(false);
            Selling.setVisible(false);
            panel3.setVisible(true);
            ItemsPanel.setVisible(false);

            Item current = theList.first;
            DefaultTableModel model = (DefaultTableModel) tbData.getModel();
            model.setRowCount(0);
            while (current != null) {
                model.addRow(new Object[]{current.itemNumber, current.name, current.qty, current.price});
                current = current.next;
            }

        }
    }

    private void btnItemActionPerformed(  ActionEvent e) {
        // TODO add your handling code here:
        ItemsPanel.setVisible(false);
        panel3.setVisible(false);
        Selling.setVisible(false);
        AddingItems.setVisible(true);
    }

    private void btnHomeActionPerformed(  ActionEvent e) {
        // TODO add your handling code here:
        panel3.hide();
        Selling.setVisible(true);
        ItemsPanel.setVisible(false);
        AddingItems.setVisible(false);

    }
    private void txtNameKeyTyped(  KeyEvent e) {
        // TODO add your handling code here:
        char input = e.getKeyChar();
        if (!(input < '0' || input > '9') && input != '\b') {
            e.consume();
            JOptionPane.showMessageDialog(this, "Name does not contain any numbers!");
        }
    }

    private void txtNumberKeyTyped(  KeyEvent e) {
        
        char input = e.getKeyChar();
        if ((input < '0' || input > '9') && input != '\b') {
            e.consume();
            JOptionPane.showMessageDialog(this, "Please enter digits!");
        }
    }

    private void txtQTYKeyTyped(  KeyEvent e) {
        
        char input = e.getKeyChar();
        if ((input < '0' || input > '9') && input != '\b') {
            e.consume();
            JOptionPane.showMessageDialog(this, "Please enter digits!");
        }
    } 

    private void txtPriceKeyTyped(  KeyEvent e) { 
        char input = e.getKeyChar();
        if ((input < '0' || input > '9') && (input != '\b' && input != '.')) {
            e.consume();
            JOptionPane.showMessageDialog(this, "Please enter digits!");
        }
    } 

    private void SoldActionPerformed(  ActionEvent e) {
        if (soldList.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Item List is empty.!");
        } else {
            AddingItems.setVisible(false);
            Selling.setVisible(false);
            panel3.setVisible(true);
            ItemsPanel.setVisible(false);

            Item current = soldList.first;
            DefaultTableModel model = (DefaultTableModel) tbData.getModel();
            model.setRowCount(0);
            while (current != null) {
                model.addRow(new Object[]{current.itemNumber, current.name, current.qty, current.price});
                current = current.next;
            }

        }
    }
    private void btn5ActionPerformed(  ActionEvent e) {
        
        System.exit(0);
    }
    
    public static void main(String args[]) {
       
        try {
            for ( UIManager.LookAndFeelInfo info :  UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                     UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MyObjects.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MyObjects.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MyObjects.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch ( UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MyObjects.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        
       
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MyObjects().setVisible(true);
                new MyObjects().Selling.setVisible(false);
                new MyObjects().panel3.setVisible(false);
                new MyObjects().ItemsPanel.setVisible(false);

            }
        });
    }

    
    private  JButton btnItem;
    private  JLabel lblItemNum;
    public  JButton btnBack;
    private  JLabel lblBill;
    public  JTable tbData;
    public  JButton btnExit;
    private  JButton btnHome;
    private  JLabel lblItem1;
    private  JLabel lblItem2;
    private  JLabel lblItem3;
    private  JLabel lblItem4;
    private  JLabel lblItem5;
    private  JLabel lblItem6;
    private  JButton btnDelete;
    private  JButton btnShow;
    private  JButton Sold;
    private  JButton btn5;
    private  JLabel lblReceipt;
    private  JScrollPane jScrollPane2;
    private  JSeparator jSeparator2;
    public  JTextField txtName;
    private  JLabel lblName;
    public  JButton btnNew;
    public  JTextField txtNumber;
    private  JLabel p1Label1;
    private  JLabel pLabel1;
    private  JPanel AddingItems;
    private  JPanel Selling;
    private  JPanel panel3;
    private  JPanel ItemsPanel;
    public  JTextField txtPrice;
    private  JLabel lblPrice;
    private  JButton btnPurchase;
    private  JLabel lblPurchase;
    private  JLabel qt1Label1;
    private  JLabel qt2Label2;
    private  JLabel qt2Label3;
    private  JLabel qt3Label2;
    private  JLabel qt3Label3;
    private  JLabel qt4Label2;
    private  JLabel qt4Label3;
    private  JLabel qt5Label2;
    private  JLabel qt5Label3;
    private  JLabel qt6Label2;
    private  JLabel qt6Label3;
    private  JLabel qtLabel1;
    public  JTextField txtQTY;
    private  JLabel lblQTY;
    public  JButton btnSave;
    private  JLabel lblShopName;
    private  JLabel lblShowBill;
    private  JButton btnStock;
    private  JLabel lblSubTotal1;
    private  JLabel lblSubTotal2;
    private  JLabel lblSubTotal3;
    private  JLabel lblSubTotal4;
    private  JLabel lblSubTotal5;
    private  JLabel lblSubTotal6;
    private  JLabel lblSubTotal7;
    private  JLabel lblTotalBill;
    private  JButton   btnSTotal;
    // End of variables declaration//GEN-END:variables
}

#include <iostream>
#include <stdio.h>
#include <string>
#include <cctype>

using namespace std;

struct Participant
{
    string members;
    string gender;
    int members_day;
    int members_month;
    int members_year;
    int age;
    int time;


};

void getInfo(Participant arrP[], int c)
{

    cout << "Enter name: ";
    cin >> arrP[c].members;

    cout << "DATE OF BIRTH" << endl;
    cout << "Enter Day (DD): ";
    cin >> arrP[c].members_day;

    cout << "Enter Month (1 to 12): ";
    cin >> arrP[c].members_month;

    cout << "Enter year (YYYY): ";
    cin >> arrP[c].members_year;

    cout << "Enter gender(M/F): ";
    cin >> arrP[c].gender;

    cout << "Enter time in minutes: ";
    cin >> arrP[c].time;
}

int calculateAge(int members_year)
{
    const int THIS_YEAR = 2022;
    int age;

    age = THIS_YEAR - members_year;

return age;

}

void displayData(Participant arrP[], int c)
{

    int age;
    cout << "List of participants" << endl;
    printf("%-10s %-10s %-15s %-10s %-10s\n", "Name", "Gender", "Birth Year", "Age", "Time in minutes");

    for(int i = 0; i < c; i++)
    {
        age = calculateAge(arrP[i].members_year);
        printf("%-10s %-10s %-15d %-10d %-10d\n", arrP[i].members.c_str(), arrP[i].gender.c_str(), arrP[i].members_year, age, arrP[i].time);
    }
}

int findWinner(Participant arrP[], int counter)
{
    int index = 0;
    Participant time = arrP[index];

    for(int i = 0; i < counter; i++)
    {
        time = arrP[i];
        index = i;
    }
}

void displayWinner(Participant arrP[], int index)
{
    Participant vP;
    int age;
    age = calculateAge(vP.members_year);
    cout << "\nWinner of the FUN RUN EVENT" << endl;
    cout << "Name:" << "\t" << arrP[index].members << endl;
    cout << "Date of birth:" << "\t" << arrP[index].members_day << "-" << arrP[index].members_month << "-" << arrP[index].members_year << endl;
    cout << "Age:" << "\t" << age << endl;
    cout << "Time in minutes:  " << arrP[index].time << endl;

}

int main()
{
    const int SIZE = 100;
    Participant arrParticipant[SIZE];
    int counter = 0;
    char answer;
    int index;

    cout << "Do you want to add a participant? (Y or N): ";
    cin >> answer;

    while(toupper(answer) == 'Y')
    {
        getInfo(arrParticipant, counter);
        counter++;

        cout << "\nDo you want to add another participant? (Y or N): ";
        cin >> answer;
    }

    displayData(arrParticipant, counter);
    findWinner(arrParticipant, counter);
    displayWinner(arrParticipant, index);



    return 0;
}



#include <iostream>

using namespace std;

int main()
{
    int userYear;
    int userAge = 0;
    int thisYear = 2022;

    cout << "Assignment 1" << endl;
    cout << "\n";
    cout << "\nEnter your year of birth (4 Digits): ";
    //INPUT - USER YEAR
    cin >> userYear;

    while((userYear < 1000) || (userYear > 9999) || (userYear >= 2022))
    {
        cout << "Year invalid! Please enter your year of birth: ";
        cin >> userYear;
    }

    if((userYear % 400 == 0) && (userYear % 100 == 0))
        cout << "Year " << userYear << " was a leap year ";
    else if((userYear % 4 == 0) && (userYear % 100 != 0))
        cout << "Year " << userYear << " was a leap year ";
    else
        cout << "Year " << userYear << " was not a leap year ";
    //PROCESSING - CALCULATE USER AGE
    userAge = thisYear - userYear;
    //OUTPUT
    cout << "\nYou are " << userAge << " years old";

    if((userYear >= 1996) && (userYear <= 2015))
        cout << "\nYou belong to generation Z ";
    else if((userYear >= 1977) && (userYear <= 1995))
        cout << "\nYou belong to generation Y ";
    else if((userYear >= 1965) && (userYear <= 1976))
        cout << "\nYou belong to generation X ";
    else if((userYear >= 1945) && (userYear <= 1964))
        cout << "\nYou are a Baby Boomer ";
    else if(userYear < 1945)
        cout << "\nYou belong to the silent generation ";
    else
        cout << "\nYour generation is still uncategorized.\n";

    cout << "\n ",
    cout << "\nDONE!" << endl;



    return 0;
}

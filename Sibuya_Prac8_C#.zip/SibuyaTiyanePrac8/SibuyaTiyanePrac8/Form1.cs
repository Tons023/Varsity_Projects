﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SibuyaTiyanePrac8
{
    public partial class Form1 : Form
    {
        
        public Form1()
        {
            InitializeComponent();
        }

        private void rdb_Automatic_CheckedChanged(object sender, EventArgs e)
        {   //Create random numbers six times
            Random rand = new Random();
            for(int i = 0; i < 6; i++)
            {
                listBox1.Items.Add(rand.Next(1, 50));
            }
            //Disable the button and txtbox
            btn_Add.Enabled = false;
            txtbox_input.Enabled = false;
        }

        private void btn_Add_Click(object sender, EventArgs e)
        {
            int numbers;

            int.TryParse(txtbox_input.Text, out numbers);
            //Validate and accept user input
            if (rdb_Manual.Checked)
            {
                if (numbers < 1 || numbers > 49)
                {
                    MessageBox.Show("Numbers must be in the range 1 to 49");
                    txtbox_input.Clear();
                }

                else if (numbers > 0 || numbers < 50)
                {
                    if (listBox1.Items.Count < 6)
                    {
                        listBox1.Items.Add(numbers);
                        txtbox_input.Clear();
                    }
                    else
                        txtbox_input.Clear();
                }
            }
            else
            {
                MessageBox.Show("Choose mode of input!");
                txtbox_input.Clear();
            }
        }

        private void btn_Results_Click(object sender, EventArgs e)
        {
            //Create random and loop 
            Random rand2 = new Random();
            int count = 0;
            for (int i = 0; i < 6; i++)
            {
                listBox2.Items.Add(rand2.Next(1, 50));
            }
            //Check items that match
            for(int i = 0; i < listBox1.Items.Count; i++)
            {
                for(int j = 0; j < listBox2.Items.Count; j++)
                {
                    if(listBox1.Items[i].ToString() == listBox2.Items[j].ToString())
                    {
                        count++;
                        label1.Text = "You have " + count + " matched";
                    }
                    else
                        label1.Text = "You have 0 matched";
                }
            }
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            //Allow user to remove items 
            if(rdb_Manual.Checked)
                listBox1.Items.Remove(listBox1.SelectedItem);
        }
    }
}

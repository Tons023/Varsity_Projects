﻿namespace SibuyaTiyanePrac8
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grbox1 = new System.Windows.Forms.GroupBox();
            this.grbox2 = new System.Windows.Forms.GroupBox();
            this.btn_Add = new System.Windows.Forms.Button();
            this.lbl1 = new System.Windows.Forms.Label();
            this.lbl2 = new System.Windows.Forms.Label();
            this.lbl3 = new System.Windows.Forms.Label();
            this.txtbox_input = new System.Windows.Forms.TextBox();
            this.rdb_Manual = new System.Windows.Forms.RadioButton();
            this.rdb_Automatic = new System.Windows.Forms.RadioButton();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.listBox2 = new System.Windows.Forms.ListBox();
            this.btn_Results = new System.Windows.Forms.Button();
            this.grbox3 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.grbox1.SuspendLayout();
            this.grbox2.SuspendLayout();
            this.grbox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // grbox1
            // 
            this.grbox1.Controls.Add(this.listBox1);
            this.grbox1.Controls.Add(this.rdb_Automatic);
            this.grbox1.Controls.Add(this.rdb_Manual);
            this.grbox1.Controls.Add(this.txtbox_input);
            this.grbox1.Controls.Add(this.lbl3);
            this.grbox1.Controls.Add(this.lbl2);
            this.grbox1.Controls.Add(this.lbl1);
            this.grbox1.Controls.Add(this.btn_Add);
            this.grbox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbox1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.grbox1.Location = new System.Drawing.Point(12, 12);
            this.grbox1.Name = "grbox1";
            this.grbox1.Size = new System.Drawing.Size(266, 328);
            this.grbox1.TabIndex = 0;
            this.grbox1.TabStop = false;
            this.grbox1.Text = "Number picker (max 6)";
            // 
            // grbox2
            // 
            this.grbox2.Controls.Add(this.grbox3);
            this.grbox2.Controls.Add(this.listBox2);
            this.grbox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbox2.Location = new System.Drawing.Point(284, 12);
            this.grbox2.Name = "grbox2";
            this.grbox2.Size = new System.Drawing.Size(265, 328);
            this.grbox2.TabIndex = 1;
            this.grbox2.TabStop = false;
            this.grbox2.Text = "Results";
            // 
            // btn_Add
            // 
            this.btn_Add.Location = new System.Drawing.Point(181, 108);
            this.btn_Add.Name = "btn_Add";
            this.btn_Add.Size = new System.Drawing.Size(47, 22);
            this.btn_Add.TabIndex = 0;
            this.btn_Add.Text = "Add";
            this.btn_Add.UseVisualStyleBackColor = true;
            this.btn_Add.Click += new System.EventHandler(this.btn_Add_Click);
            // 
            // lbl1
            // 
            this.lbl1.AutoSize = true;
            this.lbl1.Location = new System.Drawing.Point(14, 108);
            this.lbl1.Name = "lbl1";
            this.lbl1.Size = new System.Drawing.Size(115, 16);
            this.lbl1.TabIndex = 1;
            this.lbl1.Text = "Enter a number:";
            // 
            // lbl2
            // 
            this.lbl2.AutoSize = true;
            this.lbl2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl2.Location = new System.Drawing.Point(14, 124);
            this.lbl2.Name = "lbl2";
            this.lbl2.Size = new System.Drawing.Size(110, 13);
            this.lbl2.TabIndex = 2;
            this.lbl2.Text = "Number range 1 to 49";
            // 
            // lbl3
            // 
            this.lbl3.AutoSize = true;
            this.lbl3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl3.Location = new System.Drawing.Point(27, 304);
            this.lbl3.Name = "lbl3";
            this.lbl3.Size = new System.Drawing.Size(209, 13);
            this.lbl3.TabIndex = 3;
            this.lbl3.Text = "Click on any number to remove from the list";
            // 
            // txtbox_input
            // 
            this.txtbox_input.Location = new System.Drawing.Point(135, 108);
            this.txtbox_input.Name = "txtbox_input";
            this.txtbox_input.Size = new System.Drawing.Size(40, 22);
            this.txtbox_input.TabIndex = 4;
            // 
            // rdb_Manual
            // 
            this.rdb_Manual.AutoSize = true;
            this.rdb_Manual.Location = new System.Drawing.Point(30, 37);
            this.rdb_Manual.Name = "rdb_Manual";
            this.rdb_Manual.Size = new System.Drawing.Size(197, 20);
            this.rdb_Manual.TabIndex = 5;
            this.rdb_Manual.TabStop = true;
            this.rdb_Manual.Text = "Manual number selection";
            this.rdb_Manual.UseVisualStyleBackColor = true;
            // 
            // rdb_Automatic
            // 
            this.rdb_Automatic.AutoSize = true;
            this.rdb_Automatic.Location = new System.Drawing.Point(30, 60);
            this.rdb_Automatic.Name = "rdb_Automatic";
            this.rdb_Automatic.Size = new System.Drawing.Size(166, 20);
            this.rdb_Automatic.TabIndex = 6;
            this.rdb_Automatic.TabStop = true;
            this.rdb_Automatic.Text = "Quick number picker";
            this.rdb_Automatic.UseVisualStyleBackColor = true;
            this.rdb_Automatic.CheckedChanged += new System.EventHandler(this.rdb_Automatic_CheckedChanged);
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 16;
            this.listBox1.Location = new System.Drawing.Point(55, 140);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(141, 164);
            this.listBox1.TabIndex = 2;
            this.listBox1.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // listBox2
            // 
            this.listBox2.FormattingEnabled = true;
            this.listBox2.ItemHeight = 16;
            this.listBox2.Location = new System.Drawing.Point(59, 37);
            this.listBox2.Name = "listBox2";
            this.listBox2.Size = new System.Drawing.Size(146, 212);
            this.listBox2.TabIndex = 7;
            // 
            // btn_Results
            // 
            this.btn_Results.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Results.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btn_Results.Location = new System.Drawing.Point(229, 359);
            this.btn_Results.Name = "btn_Results";
            this.btn_Results.Size = new System.Drawing.Size(104, 39);
            this.btn_Results.TabIndex = 8;
            this.btn_Results.Text = "Get Results";
            this.btn_Results.UseVisualStyleBackColor = true;
            this.btn_Results.Click += new System.EventHandler(this.btn_Results_Click);
            // 
            // grbox3
            // 
            this.grbox3.Controls.Add(this.label1);
            this.grbox3.Location = new System.Drawing.Point(59, 259);
            this.grbox3.Name = "grbox3";
            this.grbox3.Size = new System.Drawing.Size(146, 45);
            this.grbox3.TabIndex = 7;
            this.grbox3.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label1.Location = new System.Drawing.Point(6, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "label1";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLight;
            this.ClientSize = new System.Drawing.Size(563, 427);
            this.Controls.Add(this.btn_Results);
            this.Controls.Add(this.grbox2);
            this.Controls.Add(this.grbox1);
            this.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.Name = "Form1";
            this.Text = "Number Guessing Game";
            this.grbox1.ResumeLayout(false);
            this.grbox1.PerformLayout();
            this.grbox2.ResumeLayout(false);
            this.grbox3.ResumeLayout(false);
            this.grbox3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grbox1;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.RadioButton rdb_Automatic;
        private System.Windows.Forms.RadioButton rdb_Manual;
        private System.Windows.Forms.TextBox txtbox_input;
        private System.Windows.Forms.Label lbl3;
        private System.Windows.Forms.Label lbl2;
        private System.Windows.Forms.Label lbl1;
        private System.Windows.Forms.Button btn_Add;
        private System.Windows.Forms.GroupBox grbox2;
        private System.Windows.Forms.ListBox listBox2;
        private System.Windows.Forms.Button btn_Results;
        private System.Windows.Forms.GroupBox grbox3;
        private System.Windows.Forms.Label label1;
    }
}


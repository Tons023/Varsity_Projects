
/**
 * Write a description of class My_Deatails here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */

import java.util.Scanner;

public class My_Deatails
{
   public static void main()
   {
      Scanner scanner = new Scanner(System.in); 
      String name = "";
      int age, snumber;
      String code = "";
      
      
      System.out.println("Enter your name and surname: ");
      name = scanner.nextLine();
      System.out.println("Enter your age: ");
      age = scanner.nextInt();
      System.out.println("Enter your student number: ");
      snumber = scanner.nextInt();
      scanner.nextLine();
      System.out.println("Enter your course code: ");
      code = scanner.nextLine();
      
      System.out.println();
      System.out.println("My name is " + name + ", I am " + age + " years old. I am" + "\n" + "registered for " + code + " and my student number is " + snumber + ".");
   }
}

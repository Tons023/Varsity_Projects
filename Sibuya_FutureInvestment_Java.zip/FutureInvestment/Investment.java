
/**
 * Write a description of class Investment here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.Scanner;
public class Investment
{
    public static void main(String[] args)
    {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter the investment amount: ");
        double in_amount = input.nextDouble();
        System.out.print("Enter the annual interest rate: ");
        double int_rate = input.nextDouble();
        System.out.print("Enter the number of years to invest: ");
        double num_years = input.nextDouble();
        
        double futureVal = 0;
        futureVal = in_amount * (1 + Math.pow((int_rate/100/12), num_years)) * 12;
        System.out.println("The future investment value is R " + futureVal);
    }
}

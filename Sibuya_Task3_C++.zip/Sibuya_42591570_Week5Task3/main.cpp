#include <iostream>
#include <stdio.h>

using namespace std;

struct Student
{
    string name;
    int pMark;
    int eMark;
    double average;
};

void display(Student arrN[], int c)
{
    cout << "\nStudent marks" << endl;
    printf("%-15s %-10s %-10s\n", "Name", "PMark", "EMark");

    for(int k = 0; k < c; k++)
    {
        printf("%-15s %-10d %-10d\n", arrN[k].name.c_str(), arrN[k].pMark, arrN[k].eMark);
    }
}

string determineResults(double average)
{
    string result = (average >= 50) ? "Pass" : "Fail";

    return result;
}

int main()
{
    const int SIZE = 10;
    Student arrStudent[SIZE];
    int counter = 0;

    cout << "Enter your name (# to stop): ";
    cin >> arrStudent[counter].name;


    while(toupper(arrStudent[counter].name[0]) != '#')
    {
        cout << "Enter your participation mark: ";
        cin >> arrStudent[counter].pMark;

        cout << "Enter your examination mark: ";
        cin >> arrStudent[counter].eMark;

        arrStudent[counter].average =
            (arrStudent[counter].pMark
                + arrStudent[counter].eMark) / 2.0;

        counter++;

        cout << "Enter another name (# to stop): ";
        cin >> arrStudent[counter].name;

    }

    display(arrStudent, counter);
    printf("%-15s %-10s %-10s\n", "Name", "Average", "Results");

    for(int k = 0; k < counter; k++)
    {
        string result = determineResults(arrStudent[k].average);

        printf("%-15s %-10.1lf %-10s\n", arrStudent[k].name.c_str(), arrStudent[k].average, result.c_str());
    }
    return 0;
}

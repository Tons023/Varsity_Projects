#include <iostream>
#include <stdio.h>

using namespace std;

struct Restaurant
{
    char name[30];
    int food;
    int service;
};

void display(Restaurant arrN[], int c)
{
    cout << "\nList of Restaurants" << endl;
    printf("%-5s %-15s %-10s %-10s\n", "#", "Name", "Food", "Service");

    for(int k = 0; k < c; k++)
    {
        printf("%-5d %-15s %-10d %-10d\n", k+1, arrN[k].name, arrN[k].food, arrN[k].service);
    }

}

void displayBestRestaurant(Restaurant arrR[], int ans)
{
    double highest = 0;
    double average[ans];
    int index;

    for(int k = 0; k < ans; k++)
    {
        average[k] = (double)(arrR[k].food + arrR[k].service) / 2;
        if((average[k] > average[k+1]))
        {
           highest = average[k];
           index = k;
        }
    }

    cout << "Best rated restaurant: " << arrR[index].name
         << "\nFood    :" << arrR[index].food
         << "\nService :" << arrR[index].service
         << "\nAverage :" << highest;
}

int main()
{
    const int SIZE = 12;
    Restaurant arrRestaurant[SIZE];
    int counter = 0;
    int number, Food_Rating, Service_Rating;

    cout << "Enter the name of a restaurant (# to stop): ";
    cin >> arrRestaurant[counter].name;

    while(toupper(arrRestaurant[counter].name[0]) != '#')
    {
        cout << "Enter the rating for food (1 to 10): ";
        cin >> arrRestaurant[counter].food;

        cout << "Enter the rating for service (1 to 10): ";
        cin >> arrRestaurant[counter].service;

        counter++;

        cout << "Enter the name of a restaurant (# to stop): ";
        cin >> arrRestaurant[counter].name;

    }

    display(arrRestaurant, counter);

    cout << "\nEnter number of restaurant from the list (1 to " << counter <<  "):";
    cin >> number;
    while(number > counter)
    {
        cout << "Invalid choice! Try again!" << endl;
        cout << "Enter number of restaurant from the list (1 to " << counter <<  "):";
        cin >> number;
    }
    cout << "Name of restaurant: " << arrRestaurant[number-1].name << endl;
    cout << "Current rating"
         << "\nFood    : " << arrRestaurant[number-1].food
         << "\nService : " << arrRestaurant[number-1].service;

    cout << "\nEnter the new rating for food (1 to 10): ";
    cin >> Food_Rating;
    arrRestaurant[number-1].food = Food_Rating;

    cout << "Enter the new rating for service (1 to 10): ";
    cin >> Service_Rating;
    arrRestaurant[number-1].service = Service_Rating;

    display(arrRestaurant, counter);
    displayBestRestaurant(arrRestaurant, counter);

    return 0;
}

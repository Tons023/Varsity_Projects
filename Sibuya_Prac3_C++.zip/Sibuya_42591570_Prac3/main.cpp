#include <iostream>
#include <cstdlib>
#include <ctype.h>

using namespace std;

void calculateSalary(string arrN[10],int arrH[10])
{
    double salary, wage;

    cout << "\nPlease enter the hourly wage: ";
    cin >> wage;

    cout << "\nEmployees and their salaries"
         << "\nNAME" << "\tHOURS" << "\tSALARY" << endl;
    for(int j = 0; j < 10; j++)
    {
        salary = arrH[j] * wage;
        cout << arrN[j] << "\t" << arrH[j] << "\t" << salary << endl;
    }
}



int main()
{
    const int SIZE = 10;
    int arrHours[SIZE];
    string arrNames[SIZE] = {"Mike", "Olivia", "Noah", "Emma", "Oliver", "Lola", "Tomas", "Amelia", "John", "Luke"};

    for(int j = 0; j < 10; j++)
    {
        cout << "Please enter the number of hours for " << arrNames[j] << ": ";
        cin >> arrHours[j];

        if((arrHours[j] < 0) || (arrHours[j] > 41))
        {
            cout << "Invalid value for hours worked! Try again\n";
            j--;
        }
    }
    calculateSalary(arrNames,arrHours);

    return 0;
}

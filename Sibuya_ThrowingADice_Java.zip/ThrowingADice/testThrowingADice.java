
/**
 * Write a description of class testThrowingADice here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */

import java.util.Random;
public class testThrowingADice
{
   public static void main(String[] args)
   {
       Random rand = new Random();
       int rand_num = rand.nextInt(1,7);
       int count = 0;
       
       System.out.println("**Throwing A Dice**");
       while(rand_num != 6 && count <= 10)
       {
           System.out.println(rand_num);
           count++;
           rand_num = rand.nextInt(1,7);
           System.out.println(rand_num);
           count++;
       }
       if(rand_num == 6)
       {
           System.out.println("A six has been thrown within " + count + "throws");
       }
       else
       {
           System.out.println("No six thrown after 10 throws");
       }
   }
}

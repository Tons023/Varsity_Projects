﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SibuyaTiyane_42591570_Prac2_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnShow_Click(object sender, EventArgs e)
        {
            pic1.Show();
            pic2.Show();
            pic3.Show();
            pic4.Show();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            pic1.Hide();
            pic2.Hide();
            pic3.Hide();
            pic4.Hide();
        }

        private void pic1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Your soft drink choice has been confirmed!");
        }

        private void pic2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Your tea choice has been confirmed!");
        }

        private void pic3_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Your beer choice has been confirmed!");
        }

        private void pic4_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Your coffee choice has been confirmed!");
        }
    }
}

#include <iostream>

using namespace std;

void displayNames(char arrN[20][30], int counter)
{
    cout << "\nList of names: " << endl;

    for(int k = 0; k < counter; k++)
    {
        cout << (k+1) << ". " << arrN[k] << endl;
    }
}

void lookupNames(char arrN[20][30], int counter)
{
  char letter;

  cout << "\nEnter a letter for search: ";
  cin >> letter;

  cout << "\nNames starting with the letter " << letter << endl;

  for(int k = 0; k < counter; k++)
  {
      if(arrN[k][0] == letter)
        cout << arrN[k] << endl;
  }
}


int main()
{
    char arrNames[20][30];
    int counter = 0;

    do
    {
        cout << "Enter a name (X to stop): ";
        cin.getline(arrNames[counter], 30);

        counter++;
    }
    while(toupper(arrNames[counter-1][0 != 'X']));

    displayNames(arrNames, counter-1);
    lookupNames(arrNames, counter);
    return 0;
}
